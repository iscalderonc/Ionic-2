var WL_CHECKSUM = {"checksum":1028557391,"date":1487317885817,"machine":"BFMXNB12682"}
/* Date: Fri Feb 17 2017 01:51:25 GMT-0600 (Central Standard Time (Mexico)) */