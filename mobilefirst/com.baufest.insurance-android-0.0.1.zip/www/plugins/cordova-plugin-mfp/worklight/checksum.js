var WL_CHECKSUM = {"checksum":2257673854,"date":1487317841005,"machine":"BFMXNB12682"}
/* Date: Fri Feb 17 2017 01:50:41 GMT-0600 (Central Standard Time (Mexico)) */